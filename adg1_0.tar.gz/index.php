<?php
$conf['qqjump']=1;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/')||strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')!==false && $conf['qqjump']==1){
$siteurl='http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
echo '<!DOCTYPE html>
<html><head>
<meta name="viewport" content="width=device-width, initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0, user-scalable=no">
<title>Hello World</title>
<frameset><frame name="main" src="//w6wg.cn/fh/tz.php" scrolling="auto" noresize></frameset></head>';
exit; }
?>
﻿<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
		<title>QQ等级加速代挂 - 爱忘事的小家伙</title>
		<meta name="Keywords" content="我爱代挂,爱代挂,免费代挂,等级加速">
		<meta name="Description" content="我爱代挂官网-全网首发支持设备锁代挂和下单秒挂，打造最稳定的QQ等级代挂全套系统，提供24小时全天候自动免费等级加速服务，让您从此解放双手，让您的QQ等级如火箭加速般的速度冲过皇冠，让QQ等级代挂如此简单！">
		<link rel="icon" type="text/css" href="favicon.ico">
		<link rel="stylesheet" type="text/css" href="css/sm.min.css">
		<link rel="stylesheet" type="text/css" href="css/sm-extend.min.css">
		<link rel="stylesheet" type="text/css" href="css/all.min.css">
		<link rel="stylesheet" type="text/css" href="css/fontawesome.min.css">
		<link rel="stylesheet" type="text/css" href="css/xiaoyao.css">
		<meta content="always" name="referrer">
		<meta name="Referrer" content="unsafe-url" />
	</head>
	<body>
	    
		<div class="page-group">
			<div class="page page-current" id="page-index">
				<div class="content native-scroll" style="background: #FFF;">
					<div class="ui-header">
						<div class="clearfix btns">
							<div class="clearfix btns">

								<a class="icon pull-right navbutt" data-panel=".panel-left">
									<!--<span></span>-->
									<!--<span></span>-->
									<!--<span></span>--></br>
								</a>
							</div>
							<div class="text_box">
								<h1 class="tite">我爱代挂官网<br>QQ等级代挂平台</h1>
								<div class="sxin">全网最稳定的QQ等级代挂网</div>
							</div>
						</div>
						<span class="xydg_bg"></span>
						<div class="waveHorizontals mobile-hide">
							<div id="waveHorizontal1" class="waveHorizontal"></div>
							<div id="waveHorizontal2" class="waveHorizontal"></div>
							<div id="waveHorizontal3" class="waveHorizontal"></div>
						</div>
					</div>
					<div class="uslo_box">
						<div class="logu">
														<img src="favicon.ico" class="xy_img" alt="代挂网未登入头像">
							<div>进入代挂网主页 ~</div>
							<div><a href="http://dg.w6wg.cn/" rel="nofollow" external>进入</a></div>
													</div>
					</div>
					<div class="content-padded">
						<div class="row" style="overflow: inherit;">
							<div class="col-100">
								<div class="xy_hot">
									<h3 class="hot_title">
										<i class="fas fa-fire"></i>
										<a href="#" rel="nofollow">热门功能</a>
										<span>享受免费带来的体验</span>
									</h3>
									<div class="hot_row">
										<div class="hot_row-row">
											<ul>
												<li>
													<a href="http://dg.w6wg.cn/">
														<i class="hot_ico" style="background-image: url(images/free.png);"></i>
														<span>免费代挂</span>
													</a>
												</li>
												<li>
													<a href="http://dg.w6wg.cn/">
														<i class="hot_ico" style="background-image: url(images/count.png);"></i>
														<span>等级计算</span>
													</a>
												</li>
												<li>
													<a href="http://200408.lanzoui.com/icEbRvegeoj">
														<i class="hot_ico" style="background-image: url(images/xycx.png);"></i>
														<span>代挂APP</span>
													</a>
												</li>
												<li>
													<a href="http://w6wg.cn/">
														<i class="hot_ico" style="background-image: url(images/dgaks.png);"></i>
														<span>加盟合作</span>
													</a>
												</li>
											</ul>
										</div>
									</div>
								</div>
								<div class="xy_row">
									<h4>网站统计</h4>
									<span>为什么选择我爱云代挂 ? </span>
								</div>
								<div class="card xy_card">
									<div class="card-content">
										<div class="card-content-inner" style="padding: 0;">
											<div class="row">
												<div class="col-33">
													<p><span class="counter">2083</span>位</p>
													<span>代理</span>
												</div>
												<div class="col-33">
													<p><span class="counter">70616</span>个</p>
													<span>代挂QQ</span>
												</div>
												<div class="col-33">
													<p><span class="counter">970</span>天</p>
													<span>稳定运营</span>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-100" style="padding-top: 1.2rem;">
								<div class="page_title">
									<h5>我爱云代挂 - 套餐价格</h5>
									<span>释放双手享受极速,安全加速</span>
								</div>
								<div class="page_row">
									<div class="card card-rad">
										<div class="xyc_header">
											<div class="header-type">全套Pro</div>
											<div class="header-prc">
												<h3>
													<span>一个月</span>
													<span><i class="fas fa-fire xyc_red"></i>10<font style="font-size: 0.8rem;margin-left: 0.1rem;">元</font></span>
												</h3>
												<p>支持设备锁<img src="images/lock.png"> 下单秒挂<img src="images/mg.png"></p>
											</div>
										</div>
										<div class="card-content" style="clear: both;">
											<div class="card-content-inner">
												<div class="xy_item">
													<div class="xy_hr">
														<i></i>
														<p>全套项目</p>
													</div>
													<ul class="item_img">
														<li><img src="images/sj.png">
															<p>手机代挂</p>
														</li>
														<li><img src="images/dn.png">
															<p>电脑代挂</p>
														</li>
														<li><img src="images/qd.png">
															<p>非隐身</p>
														</li>
														<li><img src="images/sy.png">
															<p>游戏加速</p>
														</li>
														<li><img src="images/dngj.png">
															<p>管家代挂</p>
														</li>
														<li><img src="images/xzq.png">
															<p>PC勋章墙</p>
														</li>
														<li><img src="images/wssp.png">
															<p>微视加速</p>
														</li>
														<li><img src="images/kj.png">
															<p>空间访客</p>
														</li>
														<li><img src="images/yd1.png">
															<p>QQ运动</p>
														</li>
														<li><img src="images/cm.png">
															<p>厘米加速</p>
														</li>
														<li><img src="images/bigvip.png">
															<p>大会签到</p>
														</li>
														<li><img src="images/qd_vip.png">
															<p>会员签到</p>
														</li>
														<li><img src="images/v.png">
															<p>腾讯V力</p>
														</li>
														<li><img src="images/qd_hz.png">
															<p>黄钻签到</p>
														</li>
														<li><img src="images/lan.png">
															<p>蓝钻签到</p>
														</li>
														<li><img src="images/kjht.png">
															<p>空间花藤</p>
														</li>
														<li><img src="images/daren.png">
															<p>补签卡</p>
														</li>
														<li><img src="images/mc.png">
															<p>超级萌宠</p>
														</li>
														<li><img src="images/ql.png">
															<p>情侣空间</p>
														</li>
														<li><img src="images/ld.png">
															<p>乐斗礼包</p>
														</li>
														<li><img src="images/yyqd.png">
															<p>绿钻签到</p>
														</li>
														<li><img src="images/clock.png">
															<p>早起打卡</p>
														</li>
														<li><img src="images/fireqq.png">
															<p>然鹅代跑</p>
														</li>
														<li><img src="images/cmworld.png">
															<p>厘米世界</p>
														</li>
														<li><img src="images/cmcupet.png">
															<p>厘米萌宠</p>
														</li>
														<li><img src="images/dongman.png">
															<p>动漫签到</p>
														</li>
														<li><img src="images/xinyue.png">
															<p>心悦签到</p>
														</li>
													</ul>
													<div class="item_btn">
														<a href="http://dg.w6wg.cn/" rel="nofollow" external>
															<span>立即开通</span>
														</a>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="card card-rad">
										<div class="xyc_header">
											<div class="header-type">大全套</div>
											<div class="header-prc">
												<h3>
													<span>一个月</span>
													<span><i class="fas fa-fire xyc_chen"></i>5<font style="font-size: 0.8rem;margin-left: 0.1rem;">元</font></span>
												</h3>
												<p>支持设备锁<img src="images/lock.png"> 下单秒挂<img src="images/mg.png"></p>
											</div>
										</div>
										<div class="card-content" style="clear: both;">
											<div class="card-content-inner">
												<div class="xy_item">
													<div class="xy_hr">
														<i></i>
														<p>等级项目</p>
													</div>
													<ul class="item_img">
														<li><img src="images/sj.png">
															<p>手机代挂</p>
														</li>
														<li><img src="images/dn.png">
															<p>电脑代挂</p>
														</li>
														<li><img src="images/qd.png">
															<p>非隐身</p>
														</li>
														<li><img src="images/sy.png">
															<p>游戏加速</p>
														</li>
														<li><img src="images/dngj.png">
															<p>管家代挂</p>
														</li>
														<li><img src="images/xzq.png">
															<p>PC勋章墙</p>
														</li>
														<li><img src="images/wssp.png">
															<p>微视加速</p>
														</li>
														<li><img src="images/kj.png">
															<p>空间访客</p>
														</li>
														<li><img src="images/yd1.png">
															<p>QQ运动</p>
														</li>
														<li><img src="images/cm.png">
															<p>厘米加速</p>
														</li>
													</ul>
													<div class="item_btn">
														<a href="http://dg.w6wg.cn/" rel="nofollow" external>
															<span>立即开通</span>
														</a>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="card card-rad">
										<div class="xyc_header">
											<div class="header-type">扩展包</div>
											<div class="header-prc">
												<h3>
													<span>一个月</span>
													<span><i class="fas fa-fire xyc_lan"></i>3<font style="font-size: 0.8rem;margin-left: 0.1rem;">元</font></span>
												</h3>
												<p>支持设备锁<img src="images/lock.png"> 下单秒挂<img src="images/mg.png"></p>
											</div>
										</div>
										<div class="card-content" style="clear: both;">
											<div class="card-content-inner">
												<div class="xy_item">
													<div class="xy_hr">
														<i></i>
														<p></p>
													</div>
													<ul class="item_img">
														<li><img src="images/bigvip.png">
															<p>大会签到</p>
														</li>
														<li><img src="images/qd_vip.png">
															<p>会员签到</p>
														</li>
														<li><img src="images/v.png">
															<p>腾讯V力</p>
														</li>
														<li><img src="images/qd_hz.png">
															<p>黄钻签到</p>
														</li>
														<li><img src="images/lan.png">
															<p>蓝钻签到</p>
														</li>
														<li><img src="images/kjht.png">
															<p>空间花藤</p>
														</li>
														<li><img src="images/daren.png">
															<p>补签卡</p>
														</li>
														<li><img src="images/mc.png">
															<p>超级萌宠</p>
														</li>
														<li><img src="images/ql.png">
															<p>情侣空间</p>
														</li>
														<li><img src="images/ld.png">
															<p>乐斗礼包</p>
														</li>
														<li><img src="images/yyqd.png">
															<p>绿钻签到</p>
														</li>
														<li><img src="images/clock.png">
															<p>早起打卡</p>
														</li>
														<li><img src="images/fireqq.png">
															<p>然鹅代跑</p>
														</li>
														<li><img src="images/cmworld.png">
															<p>厘米世界</p>
														</li>
														<li><img src="images/cmcupet.png">
															<p>厘米萌宠</p>
														</li>
														<li><img src="images/dongman.png">
															<p>动漫签到</p>
														</li>
														<li><img src="images/xinyue.png">
															<p>心悦签到</p>
														</li>
													</ul>
													<div class="item_btn">
														<a href="http://dg.w6wg.cn/" rel="nofollow" external>
															<span>立即开通</span>
														</a>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="card card-rad">
										<div class="xyc_header">
											<div class="header-type">加盟合作</div>
											<div class="header-prc">
												<h3>
													<span>永久使用</span>
													<span><i class="fas fa-fire xyc_lan"></i>20元<font style="font-size: 0.8rem;margin-left: 0.1rem;"></font></span>
												</h3>
												<p>低价提卡<img src="images/lock.png"> 独立网站<img src="images/mg.png"></p>
											</div>
										</div>
										<div class="card-content" style="clear: both;">
											<div class="card-content-inner">
												<div class="xy_item">
													<div class="xy_hr">
														<i></i>
														<p>包服务器域名</p>
													</div>
													<ul class="item_dj">
														<li>
															<span>全套Pro提卡成本3.12元</span>
															<span class="check_dj"></span>
														</li>
														<li>
															<span>配套网站 免费赠送</span>
															<span class="check_dj"></span>
														</li>
														<li>
															<span>成本提卡自用省钱卖给用户赚钱</span>
															<span class="check_dj"></span>
														</li>
														<li>
															<span>包配服务器程序升级免费更新</span>
															<span class="check_dj"></span>
														</li>
														<li>
															<span>配备三网支付接口资金自己保管</span>
															<span class="check_dj"></span>
														</li>
														<li>
															<span>可招收代理 搭建同款网站</span>
															<span class="check_dj"></span>
														</li>
														<li>
															<span>全程指导月收入2000+</span>
															<span class="check_dj"></span>
														</li>
													</ul>
													<div class="item_btn">
														<a href="http://dg.w6wg.cn/" rel="nofollow" external>
															<span>查看套餐</span>
														</a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="app_down">
						<div class="row">
							<div class="col-100">
								<div class="app_row">
									<div class="app_title">
										<h5>代挂APP免费使用</h5>
										<p>APP支持多账号关联切换,更快速简单的操作您的代挂QQ,黑科技一键计算升级所需天速查询代挂进度,更多黑科技功能等你来体验！</p>
										<div class="app_btn">
											<a href="http://200408.lanzoui.com/icEbRvegeoj" rel="nofollow" external>
												<i class="fa fa-arrow-circle-down"></i>
												<span>立即下载</span>
											</a>
										</div>
									</div>
								</div>
								<div class="app_imgs">
									<div class="d_imgs">
										<img src="images/appdown.png" alt="代挂APP演示图">
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="footer">
						<div class="row" style="padding: 1.5rem 0.8rem 0.9rem;">
							<div class="col-25">
								<a href="http://dg.w6wg.cn/" rel="nofollow" target="_blank" external>
									<img src="images/ikm.png" alt="代挂卡密购买">
									<span>卡密购买</span>
								</a>
							</div>
							<div class="col-25">
								<a href="http://dg.w6wg.cn/" rel="nofollow">
									<img src="images/izx.png" alt="代挂在线购买">
									<span>在线开通</span>
								</a>
							</div>
							<div class="col-25">
								<a href="http://dg.w6wg.cn/" rel="nofollow">
									<img src="images/ius.png" alt="书生代挂网用户中心">
									<span>用户中心</span>
								</a>
							</div>
							<div class="col-25">
								<a href="http://res.abeim.cn/api/qq/?qq=1511942692" target="_blank" rel="nofollow" external>
									<img src="images/ikf.png" alt="24小时在线客服">
									<span>联系客服</span>
								</a>
							</div>
						</div>
						<div class="row footer_c" style="padding: 0 0 0.3rem 0">
							<div class="col-100">
								<div class="icp_c">
									Copyright © 我爱云代挂								</div>
							</div>
							<div class="col-100" style="padding-top:8px">
								<!--<div class="icp_c">-->
								<!--	<a href="http://icp.gov.moe/?keyword=20213999" target="_blank">萌ICP备20213999号</a>-->
									<div class="card-head"><i class="fa fa-link fa-fw"></i>友情链接</div>
    <div class="card-body">
        
        
                  	</div>
							</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="panel panel-left panel-cover" style>
				<div class="content-block">
					<ul class="index_ul">
						<li><a href="http://adg.w6wg.cn/">首页</a></li>
						<li><a href="http://dg.w6wg.cn/" external>开通代挂</a></li>
						<li><a href="http://dg.w6wg.cn/" external>代挂查询</a></li>
						<li><a href="http://dg.w6wg.cn/" external>新手帮助</a></li>
					</ul>
				</div>
			</div>
		</div>
		<script src="js/jquery.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="js/jquery.waypoints.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="js/jquery.countup.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="js/layer.js" type="text/javascript" charset="utf-8"></script>
		<script src="js/xiaoyao.js" type="text/javascript" charset="utf-8"></script>
		<script src="js/sm.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="js/sm-extend.min.js" type="text/javascript" charset="utf-8"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				$('.counter').countUp();
				var navbtn = $('.navbutt');
				var panel2 = $('.panel-cover');
				$('.navbutt').click(function() {
					if (panel2.css('display') == 'block') {
						navbtn.removeClass('open-panel');
						navbtn.addClass('close-panel');
					} else {
						navbtn.removeClass('close-panel');
						navbtn.addClass('open-panel');
					}
				});
			});
		</script>
	<script>
// 			$.alert('');
// 		</script>
			</body>
</html>
