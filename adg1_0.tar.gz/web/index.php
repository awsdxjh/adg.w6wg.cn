<!DOCTYPE html>
<html lang="zh">

<head>
	<meta charset="UTF-8">
	<title>三合一收款码 - 爱忘事的小家伙</title>
</head>

<body>

	</footer>
	<!-- footer结束 -->
	<script src="//cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
	<script src="//cdn.bootcss.com/Swiper/4.5.0/js/swiper.min.js"></script>
	<script src="http://skm.w6wg.cn/layui/layui.js" type="text/javascript" charset="utf-8"></script>
	<script src="http://skm.w6wg.cn/js/index.js" type="text/javascript" charset="utf-8"></script>
</body>

</html>